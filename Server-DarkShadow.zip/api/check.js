export default async function handler(req, res) {
  const url = "http://wyiiprivatajaib.srv-cloud.biz.id:2551";

  try {
    const response = await fetch(url, {
      method: "HEAD"
    });

    if (response.ok) {
      res.status(200).send("online");
    } else {
      res.status(200).send("offline");
    }

  } catch (err) {
    res.status(200).send("offline");
  }
}